# Project 3: Around The U.S.

### Overview  
  
  Hello my name is Nahaliel Green and this is my sprint 3 project for Triple ten software engineering bootcamp.
  My job was to create a innovative webpage for world reknown explorer Jaques Costeau. 
  Highlighting his journey around the world 🏔️🌊, and his amazing photos 📸 of his trip.
  My goal of this project was to implement my design skills that I have learned over the course of my time im the program.
  

### Project Feautures 
  - flexbox
  - grid layout
  - responsive design
  - media queries 


### Video Link

  Below is a link to my youtube video of me walking through and giving a overview of my project,and how i designed it. Also a link to my github repository with a indepth view of the code Enjoy ! 😎
 
  https://youtu.be/XJeRjfgdZz0

  https://github.com/pablobetheplug/se_project_aroundtheus
